#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
usage() {
  echo 'Usage: sudo bash deploy.sh --publish DIR --app NAME --domain HOST --cert CERT.pem --key KEY.pem --config production.json [--port 5080] [--install-deps]' >&2
  exit 2
}
publish= app= domain= cert= key= config= port=5080 install_deps=0
while (($#)); do
  case "$1" in
    --publish|--app|--domain|--cert|--key|--config|--port)
      (($# >= 2)) || usage
      case "$1" in
        --publish) publish=$2;; --app) app=$2;; --domain) domain=$2;;
        --cert) cert=$2;; --key) key=$2;; --config) config=$2;; --port) port=$2;;
      esac
      shift 2;;
    --install-deps) install_deps=1; shift;;
    *) usage;;
  esac
done
[[ $EUID -eq 0 ]] || { echo 'Run with sudo.' >&2; exit 1; }
[[ -d /run/systemd/system ]] || { echo 'This script requires a Linux server running systemd.' >&2; exit 1; }
[[ -n "$publish" && -n "$app" && -n "$domain" && -n "$cert" && -n "$key" && -n "$config" ]] || usage
[[ "$app" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]] || { echo 'Invalid application executable name.' >&2; exit 1; }
[[ "$domain" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]$ && "$domain" != *..* ]] || { echo 'Invalid domain.' >&2; exit 1; }
[[ "$port" =~ ^[0-9]+$ && ${#port} -le 5 && $port -ge 1024 && $port -le 65535 ]] || { echo 'Invalid port.' >&2; exit 1; }
if ((install_deps)); then
  command -v apt-get >/dev/null || { echo '--install-deps supports Debian/Ubuntu only.' >&2; exit 1; }
  apt-get update
  apt-get install -y nginx curl jq libicu-dev ca-certificates
fi
for command in nginx curl jq systemctl realpath flock; do
  command -v "$command" >/dev/null || { echo "Install prerequisite: $command" >&2; exit 1; }
done
exec 9>/run/lock/workbench-gateway-deploy.lock
flock -n 9 || { echo 'Another deployment is running.' >&2; exit 1; }
publish=$(realpath "$publish"); cert=$(realpath "$cert"); key=$(realpath "$key"); config=$(realpath "$config")
[[ -d "$publish" && -f "$publish/$app" && -f "$cert" && -f "$key" && -f "$config" ]] || { echo 'Published executable, TLS files or configuration missing.' >&2; exit 1; }
[[ -f "$publish/$app.runtimeconfig.json" ]] || { echo 'Supply the full published API folder, not the source package.' >&2; exit 1; }
# Paths interpolated into Nginx/systemd must contain no whitespace or control characters.
[[ "$cert" =~ ^/[A-Za-z0-9_./-]+$ && "$key" =~ ^/[A-Za-z0-9_./-]+$ ]] || { echo 'TLS paths must use simple absolute paths.' >&2; exit 1; }
jq -e '.GatewayAuth.SigningKeyBase64 | type == "string" and length >= 44' "$config" >/dev/null || { echo 'Missing JWT signing key in protected configuration.' >&2; exit 1; }
jq -e '.GatewayAuth.Users | length > 0' "$config" >/dev/null || { echo 'Provision at least one user.' >&2; exit 1; }
jq -e --arg domain "$domain" '.AllowedHosts == $domain' "$config" >/dev/null || { echo 'Set AllowedHosts to the exact deployment domain in production.json.' >&2; exit 1; }
base=/opt/workbench-gateway
settings=/etc/workbench-gateway
unit=/etc/systemd/system/workbench-gateway.service
site=/etc/nginx/conf.d/workbench-gateway.conf
install -d -m 755 "$base/releases"
install -d -m 700 "$settings"
id -u workbench-gateway >/dev/null 2>&1 || useradd --system --home-dir /var/lib/workbench-gateway --shell /usr/sbin/nologin workbench-gateway
install -d -m 700 -o workbench-gateway -g workbench-gateway /var/lib/workbench-gateway /var/lib/workbench-gateway/keys
previous=$(readlink -f "$base/current" || true)
backup=$(mktemp -d "$base/deployment-backup.XXXXXXXX")
for file in "$unit" "$site" "$settings/production.json"; do
  if [[ -f "$file" ]]; then cp -p "$file" "$backup/$(basename "$file")"; fi
done
release=$(mktemp -d "$base/releases/release.XXXXXXXX")
cp -a "$publish/." "$release/"
chown -R root:root "$release"
chmod -R go-w "$release"
chmod 755 "$release" "$release/$app"
changed=0
rollback() {
  status=$?
  trap - ERR
  if ((changed)); then
    echo "Deployment failed; restoring configuration from $backup" >&2
    for file in "$unit" "$site" "$settings/production.json"; do
      name=$(basename "$file")
      if [[ -f "$backup/$name" ]]; then cp -p "$backup/$name" "$file"; else rm -f -- "$file"; fi
    done
    if [[ -n "$previous" && "$previous" == "$base/releases/"* ]]; then
      ln -sfn "$previous" "$base/current"
      systemctl daemon-reload
      systemctl restart workbench-gateway || true
    else
      systemctl stop workbench-gateway || true
      systemctl disable workbench-gateway || true
      systemctl daemon-reload
    fi
    nginx -t && systemctl reload nginx || true
  fi
  exit "$status"
}
trap rollback ERR
changed=1
install -m 600 "$config" "$settings/production.json"
# systemd credentials expose the secret file to the service without granting access to /etc.
cat > "$unit" <<UNIT
[Unit]
Description=WorkBench SQL Gateway API
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=workbench-gateway
Group=workbench-gateway
WorkingDirectory=$base/current
ExecStart=$base/current/$app
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=ASPNETCORE_URLS=http://127.0.0.1:$port
Environment=ASPNETCORE_HTTPS_PORT=443
LoadCredential=production.json:$settings/production.json
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
StateDirectory=workbench-gateway
StateDirectoryMode=0700
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/workbench-gateway
UMask=0077

[Install]
WantedBy=multi-user.target
UNIT
cat > "$site" <<NGINX
server {
    listen 80;
    server_name $domain;
    return 301 https://$domain\$request_uri;
}
server {
    listen 443 ssl;
    server_name $domain;
    ssl_certificate $cert;
    ssl_certificate_key $key;
    ssl_protocols TLSv1.2 TLSv1.3;
    client_max_body_size 2m;
    location / {
        proxy_pass http://127.0.0.1:$port;
        proxy_http_version 1.1;
        proxy_set_header Host $domain;
        proxy_set_header X-Forwarded-For \$remote_addr;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Authorization \$http_authorization;
        proxy_read_timeout 660s;
        proxy_send_timeout 660s;
        proxy_connect_timeout 10s;
    }
}
NGINX
chmod 644 "$unit" "$site"
nginx -t
ln -sfn "$release" "$base/current"
systemctl daemon-reload
systemctl enable workbench-gateway
systemctl restart workbench-gateway
ready=0
for attempt in $(seq 1 30); do
  if curl -fsS --max-time 2 -H "Host: $domain" "http://127.0.0.1:$port/gateway/login" >/dev/null; then ready=1; break; fi
  sleep 1
done
[[ "$ready" == 1 ]] || { echo 'API startup check failed; inspect journalctl -u workbench-gateway.' >&2; false; }
systemctl enable nginx
if systemctl is-active --quiet nginx; then systemctl reload nginx; else systemctl start nginx; fi
curl -fsS --max-time 10 --resolve "$domain:443:127.0.0.1" "https://$domain/gateway/login" >/dev/null
code=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 --resolve "$domain:443:127.0.0.1" -H 'Content-Type: application/json' -d '{}' "https://$domain/api/dbsession/open")
[[ "$code" == 401 ]] || { echo "Expected unauthenticated API rejection 401, received $code." >&2; false; }
trap - ERR
echo "Deployed: https://$domain/gateway/login"
echo "Release: $release"
echo "Previous release: $previous"
echo "Configuration backups: $backup (root-only; retain securely)."
echo 'Logs: sudo journalctl -u workbench-gateway -f'
