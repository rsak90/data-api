#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo 'Usage: bash publish.sh /path/to/WorkBench.Api.csproj /path/to/output [linux-x64|linux-arm64]' >&2; exit 2
fi
project=$(realpath "$1")
output=$(realpath -m "$2")
rid=${3:-linux-x64}
[[ -f "$project" && "$project" == *.csproj ]] || { echo 'API csproj not found.' >&2; exit 1; }
[[ "$rid" == linux-x64 || "$rid" == linux-arm64 ]] || { echo 'Unsupported RID.' >&2; exit 1; }
command -v dotnet >/dev/null || { echo 'Install .NET SDK 9 or later on the build machine.' >&2; exit 1; }
mkdir -p "$output"
release=$(mktemp -d "$output/publish.XXXXXXXX")
dotnet publish "$project" -c Release -r "$rid" --self-contained true -p:UseAppHost=true -o "$release"
echo "Published API: $release"
echo 'Deploy the complete published directory, including Views/static content and Oracle dependencies.'
