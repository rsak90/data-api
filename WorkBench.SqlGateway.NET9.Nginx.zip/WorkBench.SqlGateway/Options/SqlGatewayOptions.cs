using System.ComponentModel.DataAnnotations;

namespace WorkBench.Api.Options;

public sealed class SqlGatewayOptions
{
    public const string SectionName = "SqlGateway";

    [Range(1, 1440)] public int AbsoluteTimeoutMinutes { get; init; } = 60;
    [Range(1, 1440)] public int SlidingTimeoutMinutes { get; init; } = 20;
    [Range(100, 1_000_000)] public int MaxSqlLength { get; init; } = 50_000;
    [Range(1, 100_000)] public int DefaultMaxRows { get; init; } = 10_000;
    [Range(1, 100_000)] public int MaximumMaxRows { get; init; } = 100_000;
    [Range(1, 600)] public int DefaultCommandTimeoutSeconds { get; init; } = 60;
    [Range(1, 600)] public int MaximumCommandTimeoutSeconds { get; init; } = 600;
}
