%include '/path/to/dbcon.sas';
%include '/path/to/dbsql.sas';
%include '/path/to/dbdisconnect.sas';

%dbcon(baseurl=https://workbench.example.internal);

%dbsql(
  sql=%nrstr(SELECT employee_id, employee_name FROM employees WHERE department_id = 10 ORDER BY employee_id),
  out=work.employees,
  maxrows=500,
  timeout=30
);

%put NOTE: statement=&db_statement_type rows=&db_row_count affected=&db_affected_rows;
%put NOTE: message=&db_message correlation=&db_correlation_id;

%dbsql(
  sql=%nrstr(UPDATE employees SET last_viewed_utc = SYSTIMESTAMP WHERE employee_id = 101),
  out=work.update_result
);

%dbdisconnect;
