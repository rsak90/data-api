%macro dbdisconnect(tokenfile=/jcr/Ajith_Kumar/Token/token.txt);
  %global gdbsessionid gdbconnected db_message db_correlation_id;
  %local _db_jwt _db_status;
  %if %superq(gdbsessionid)= %then %goto clear_session;

  filename _dbtoken "&tokenfile" encoding='utf-8';
  data _null_;
    infile _dbtoken lrecl=32767 truncover;
    input;
    if _n_=1 then call symputx('_db_jwt',strip(_infile_),'L');
  run;
  filename _dbtoken clear;
  filename _dbreq temp encoding='utf-8';
  filename _dbresp temp encoding='utf-8';
  data _null_; file _dbreq; put '{"sessionId":"' "&gdbsessionid" +(-1) '"}'; run;
  proc http method='POST' url="&gdbbaseurl/api/dbsession/close"
      in=_dbreq out=_dbresp ct='application/json';
    headers 'Authorization'="Bearer &_db_jwt" 'Accept'='application/json';
  run;
  %let _db_status=&SYS_PROCHTTP_STATUS_CODE;
  filename _dbreq clear;
  filename _dbresp clear;

%clear_session:
  %let gdbsessionid=;
  %let gdbconnected=0;
  %if %symexist(gdbbaseurl) %then %let gdbbaseurl=;
%mend dbdisconnect;
