%macro dbcon(baseurl=, tokenfile=/jcr/Ajith_Kumar/Token/token.txt);
  %global gdbsessionid gdbconnected gdbbaseurl db_message db_correlation_id;
  %local _db_jwt _db_status;
  %let gdbsessionid=;
  %let gdbconnected=0;
  %let gdbbaseurl=%sysfunc(prxchange(s/\/$//,1,%superq(baseurl)));
  %let db_message=;
  %let db_correlation_id=;

  %if %superq(gdbbaseurl)= %then %do;
    %let db_message=baseurl is required.;
    %put ERROR: &db_message;
    %return;
  %end;

  filename _dbtoken "&tokenfile" encoding='utf-8';
  data _null_;
    length token $32767;
    infile _dbtoken lrecl=32767 truncover;
    input;
    token=strip(_infile_);
    if _n_=1 then call symputx('_db_jwt',token,'L');
  run;
  filename _dbtoken clear;

  %if %superq(_db_jwt)= %then %do;
    %let db_message=JWT token file is empty or unreadable.;
    %put ERROR: &db_message;
    %return;
  %end;

  filename _dbreq temp encoding='utf-8';
  filename _dbresp temp encoding='utf-8';
  data _null_; file _dbreq; put '{}'; run;
  proc http method='POST' url="&gdbbaseurl/api/dbsession/open"
      in=_dbreq out=_dbresp ct='application/json';
    headers 'Authorization'="Bearer &_db_jwt" 'Accept'='application/json';
  run;
  %let _db_status=&SYS_PROCHTTP_STATUS_CODE;

  %if &_db_status=200 %then %do;
    libname _dbjson json fileref=_dbresp;
    data _null_;
      set _dbjson.root;
      call symputx('gdbsessionid',sessionId,'G');
      call symputx('gdbconnected',success,'G');
      call symputx('db_message',message,'G');
      call symputx('db_correlation_id',correlationId,'G');
    run;
    libname _dbjson clear;
  %end;
  %else %do;
    %let db_message=OPEN failed with HTTP status &_db_status.;
    %put ERROR: &db_message;
  %end;
  filename _dbreq clear;
  filename _dbresp clear;
%mend dbcon;
