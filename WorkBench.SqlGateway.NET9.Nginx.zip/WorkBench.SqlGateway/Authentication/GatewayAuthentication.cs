using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.IdentityModel.Tokens;
using WorkBench.Api.Services.SqlGateway;

namespace WorkBench.Api.Authentication;

public sealed class GatewayAuthOptions
{
    public string Issuer { get; set; } = "WorkBench";
    public string Audience { get; set; } = "WorkBench.SqlGateway";
    public string SigningKeyBase64 { get; set; } = "";
    public int TokenLifetimeMinutes { get; set; } = 60;
    public List<GatewayUser> Users { get; set; } = [];
}

public sealed class GatewayUser
{
    public string Id { get; set; } = "";
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public bool Enabled { get; set; } = true;
}

public static class GatewayAuthentication
{
    public const string Bearer = "GatewayBearer";
    public const string Cookie = "GatewayBrowser";

    public static IServiceCollection AddGatewayAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var options = configuration.GetSection("GatewayAuth").Get<GatewayAuthOptions>() ?? new();
        byte[] key;
        try { key = Convert.FromBase64String(options.SigningKeyBase64); }
        catch (FormatException ex) { throw new InvalidOperationException("GatewayAuth signing key must be Base64.", ex); }
        if (key.Length < 32 || options.TokenLifetimeMinutes is < 1 or > 1440 ||
            string.IsNullOrWhiteSpace(options.Issuer) || string.IsNullOrWhiteSpace(options.Audience))
            throw new InvalidOperationException("Configure a random signing key of at least 32 bytes, issuer, audience and a valid token lifetime.");
        if (options.Users.Any(u => string.IsNullOrWhiteSpace(u.Id) || string.IsNullOrWhiteSpace(u.Username) || string.IsNullOrWhiteSpace(u.PasswordHash)) ||
            options.Users.Select(u => u.Id).Distinct(StringComparer.Ordinal).Count() != options.Users.Count ||
            options.Users.Select(u => u.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count() != options.Users.Count)
            throw new InvalidOperationException("Each gateway user requires a unique ID, unique username and password hash.");
        services.AddSingleton(options);
        services.AddSingleton<IPasswordHasher<GatewayUser>, PasswordHasher<GatewayUser>>();
        services.AddScoped<IWorkbenchTokenIssuer, GatewayJwtIssuer>();
        services.AddAuthentication()
            .AddCookie(Cookie, cookie =>
            {
                cookie.LoginPath = "/gateway/login";
                cookie.Cookie.Name = "__Host-WorkBenchGateway";
                cookie.Cookie.HttpOnly = true;
                cookie.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                cookie.Cookie.SameSite = SameSiteMode.Strict;
                cookie.ExpireTimeSpan = TimeSpan.FromMinutes(20);
                cookie.SlidingExpiration = false;
                cookie.Events.OnValidatePrincipal = async context =>
                {
                    if (!options.Users.Any(u => u.Enabled && u.Id == context.Principal?.FindFirstValue("sub")))
                    {
                        context.RejectPrincipal();
                        await context.HttpContext.SignOutAsync(Cookie);
                    }
                };
            })
            .AddJwtBearer(Bearer, jwt =>
            {
                jwt.MapInboundClaims = false;
                jwt.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidAlgorithms = [SecurityAlgorithms.HmacSha256],
                    ValidateIssuer = true, ValidIssuer = options.Issuer,
                    ValidateAudience = true, ValidAudience = options.Audience,
                    ValidateLifetime = true, RequireExpirationTime = true,
                    RequireSignedTokens = true, ClockSkew = TimeSpan.FromSeconds(30),
                    NameClaimType = "name"
                };
                jwt.Events = new JwtBearerEvents
                {
                    OnTokenValidated = context =>
                    {
                        if (!options.Users.Any(u => u.Enabled && u.Id == context.Principal?.FindFirstValue("sub")))
                            context.Fail("User account is unavailable.");
                        return Task.CompletedTask;
                    }
                };
            });
        services.AddAuthorization(auth =>
        {
            auth.AddPolicy("GatewayTokenPage", policy => policy.AddAuthenticationSchemes(Cookie).RequireAuthenticatedUser());
            auth.AddPolicy("GatewayApi", policy => policy.AddAuthenticationSchemes(Bearer).RequireAuthenticatedUser());
        });
        services.AddRateLimiter(limiter => limiter.AddFixedWindowLimiter("GatewayLogin", window =>
        {
            window.PermitLimit = 10;
            window.Window = TimeSpan.FromMinutes(1);
            window.QueueLimit = 0;
        }));
        return services;
    }
}

public sealed class GatewayJwtIssuer(GatewayAuthOptions options) : IWorkbenchTokenIssuer
{
    public Task<GeneratedGatewayToken> IssueAsync(ClaimsPrincipal user, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var id = user.FindFirstValue("sub");
        var account = options.Users.SingleOrDefault(u => u.Enabled && u.Id == id)
            ?? throw new UnauthorizedAccessException("Account is unavailable.");
        var now = DateTimeOffset.UtcNow;
        var expires = now.AddMinutes(options.TokenLifetimeMinutes);
        var token = new JwtSecurityToken(options.Issuer, options.Audience,
            [new Claim("sub", account.Id), new Claim("client_id", account.Id),
             new Claim("name", account.Username), new Claim("jti", Guid.NewGuid().ToString("N"))],
            now.UtcDateTime, expires.UtcDateTime,
            new SigningCredentials(new SymmetricSecurityKey(Convert.FromBase64String(options.SigningKeyBase64)), SecurityAlgorithms.HmacSha256));
        return Task.FromResult(new GeneratedGatewayToken(new JwtSecurityTokenHandler().WriteToken(token), expires));
    }
}

[Route("gateway")]
public sealed class GatewayLoginController(GatewayAuthOptions options, IPasswordHasher<GatewayUser> hasher) : Controller
{
    private static readonly GatewayUser Dummy = new();
    private static readonly string DummyHash = new PasswordHasher<GatewayUser>().HashPassword(Dummy, Guid.NewGuid().ToString());

    [HttpGet("login")]
    public IActionResult Login()
    {
        Response.Headers.CacheControl = "no-store";
        return View("~/Views/GatewayToken/Login.cshtml");
    }

    [HttpPost("login")]
    [ValidateAntiForgeryToken]
    [EnableRateLimiting("GatewayLogin")]
    public async Task<IActionResult> Login(string username, string password)
    {
        Response.Headers.CacheControl = "no-store";
        var user = options.Users.SingleOrDefault(u => u.Enabled && string.Equals(u.Username, username, StringComparison.OrdinalIgnoreCase));
        var valid = hasher.VerifyHashedPassword(user ?? Dummy, user?.PasswordHash ?? DummyHash, password ?? "");
        if (user is null || valid == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError("", "Invalid username or password.");
            Response.StatusCode = 401;
            return View("~/Views/GatewayToken/Login.cshtml");
        }
        var identity = new ClaimsIdentity([new Claim("sub", user.Id), new Claim(ClaimTypes.Name, user.Username)], GatewayAuthentication.Cookie);
        await HttpContext.SignInAsync(GatewayAuthentication.Cookie, new ClaimsPrincipal(identity));
        return RedirectToAction("Index", "GatewayToken");
    }

    [HttpPost("logout")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(GatewayAuthentication.Cookie);
        return RedirectToAction(nameof(Login));
    }
}
