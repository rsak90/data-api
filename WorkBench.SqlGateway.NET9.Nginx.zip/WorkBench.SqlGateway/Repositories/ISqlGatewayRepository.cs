using WorkBench.Api.Models.SqlGateway;

namespace WorkBench.Api.Repositories.SqlGateway;

public sealed record SqlGatewayCommand(
    string Sql,
    string StatementType,
    IReadOnlyDictionary<string, System.Text.Json.JsonElement> Parameters,
    int MaxRows,
    int TimeoutSeconds);

public interface ISqlGatewayRepository
{
    Task<SqlExecuteResponse> ExecuteAsync(SqlGatewayCommand command, string correlationId, CancellationToken cancellationToken);
}
