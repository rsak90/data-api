using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Oracle.ManagedDataAccess.Client;
using WorkBench.Api.Data; // INTEGRATION: replace if WorkbenchContext is in another namespace.
using WorkBench.Api.Models.SqlGateway;

namespace WorkBench.Api.Repositories.SqlGateway;

public sealed partial class SqlGatewayRepository(WorkbenchContext context, ILogger<SqlGatewayRepository> logger)
    : ISqlGatewayRepository
{
    public async Task<SqlExecuteResponse> ExecuteAsync(
        SqlGatewayCommand request,
        string correlationId,
        CancellationToken cancellationToken)
    {
        var connection = context.Database.GetDbConnection();
        var openedHere = connection.State != ConnectionState.Open;
        try
        {
            if (openedHere) await connection.OpenAsync(cancellationToken);
            return request.StatementType == "SELECT" || request.StatementType == "WITH"
                ? await ExecuteQueryAsync(connection, request, correlationId, cancellationToken)
                : await ExecuteWriteAsync(connection, request, correlationId, cancellationToken);
        }
        finally
        {
            // This scoped context does not own a long-lived session. Return the connection to the existing pool.
            if (openedHere && connection.State != ConnectionState.Closed)
                await connection.CloseAsync();
        }
    }

    private async Task<SqlExecuteResponse> ExecuteQueryAsync(
        DbConnection connection, SqlGatewayCommand request, string correlationId, CancellationToken cancellationToken)
    {
        await using var command = CreateCommand(connection, request, transaction: null);
        await using var reader = await command.ExecuteReaderAsync(CommandBehavior.SequentialAccess, cancellationToken);
        var rows = new List<IReadOnlyDictionary<string, object?>>(Math.Min(request.MaxRows, 1024));
        while (rows.Count < request.MaxRows && await reader.ReadAsync(cancellationToken))
        {
            var row = new Dictionary<string, object?>(reader.FieldCount, StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < reader.FieldCount; i++)
            {
                var baseName = reader.GetName(i);
                var name = baseName;
                for (var suffix = 2; row.ContainsKey(name); suffix++) name = $"{baseName}_{suffix}";
                row[name] = await reader.IsDBNullAsync(i, cancellationToken) ? null : NormalizeValue(reader.GetValue(i));
            }
            rows.Add(row);
        }

        return new SqlExecuteResponse
        {
            Success = true, StatementType = request.StatementType, RowCount = rows.Count, AffectedRows = 0,
            Rows = rows, Message = rows.Count == request.MaxRows ? "Query succeeded; maximum row limit reached." : "Query succeeded.",
            CorrelationId = correlationId
        };
    }

    private async Task<SqlExecuteResponse> ExecuteWriteAsync(
        DbConnection connection, SqlGatewayCommand request, string correlationId, CancellationToken cancellationToken)
    {
        await using var transaction = await connection.BeginTransactionAsync(IsolationLevel.ReadCommitted, cancellationToken);
        try
        {
            await using var command = CreateCommand(connection, request, transaction);
            var affected = await command.ExecuteNonQueryAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            return new SqlExecuteResponse
            {
                Success = true, StatementType = request.StatementType, RowCount = 0, AffectedRows = affected,
                Message = "Statement executed and committed.", CorrelationId = correlationId
            };
        }
        catch
        {
            try { await transaction.RollbackAsync(CancellationToken.None); }
            catch (Exception rollbackException) { logger.LogError(rollbackException, "Rollback failed. CorrelationId={CorrelationId}", correlationId); }
            throw;
        }
    }

    private static DbCommand CreateCommand(DbConnection connection, SqlGatewayCommand request, DbTransaction? transaction)
    {
        var command = connection.CreateCommand();
        command.CommandText = request.Sql;
        command.CommandType = CommandType.Text;
        command.CommandTimeout = request.TimeoutSeconds;
        command.Transaction = transaction;
        if (command is OracleCommand oracleCommand) oracleCommand.BindByName = true;

        foreach (var pair in request.Parameters)
        {
            var parameterName = pair.Key.TrimStart(':');
            if (!ParameterNameRegex().IsMatch(parameterName))
                throw new ArgumentException($"Invalid parameter name '{pair.Key}'.", nameof(request));
            var parameter = command.CreateParameter();
            parameter.ParameterName = parameterName;
            SetParameterValue(parameter, pair.Value);
            command.Parameters.Add(parameter);
        }
        return command;
    }

    private static void SetParameterValue(DbParameter parameter, JsonElement value)
    {
        switch (value.ValueKind)
        {
            case JsonValueKind.Null:
            case JsonValueKind.Undefined:
                parameter.Value = DBNull.Value;
                break;
            case JsonValueKind.String:
                var text = value.GetString();
                if (Guid.TryParse(text, out var guid)) { parameter.DbType = DbType.String; parameter.Value = guid.ToString(); }
                else if (DateTimeOffset.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var dto))
                { parameter.DbType = DbType.DateTimeOffset; parameter.Value = dto; }
                else { parameter.DbType = DbType.String; parameter.Value = text ?? string.Empty; }
                break;
            case JsonValueKind.Number:
                if (value.TryGetInt64(out var integer)) { parameter.DbType = DbType.Int64; parameter.Value = integer; }
                else if (value.TryGetDecimal(out var dec)) { parameter.DbType = DbType.Decimal; parameter.Value = dec; }
                else { parameter.DbType = DbType.Double; parameter.Value = value.GetDouble(); }
                break;
            case JsonValueKind.True:
            case JsonValueKind.False:
                parameter.DbType = DbType.Int16;
                parameter.Value = value.GetBoolean() ? 1 : 0;
                break;
            default:
                // Objects and arrays are sent as JSON text; callers may cast them to Oracle JSON/CLOB in SQL.
                parameter.DbType = DbType.String;
                parameter.Value = value.GetRawText();
                break;
        }
    }

    private static object? NormalizeValue(object value) => value switch
    {
        DBNull => null,
        byte[] bytes => Convert.ToBase64String(bytes),
        DateTime date => date.ToUniversalTime(),
        DateTimeOffset dto => dto.ToUniversalTime(),
        string or bool or byte or short or int or long or float or double or decimal => value,
        _ => Convert.ToString(value, CultureInfo.InvariantCulture)
    };

    [GeneratedRegex(@"^[A-Za-z][A-Za-z0-9_$#]*$", RegexOptions.CultureInvariant)]
    private static partial Regex ParameterNameRegex();
}
