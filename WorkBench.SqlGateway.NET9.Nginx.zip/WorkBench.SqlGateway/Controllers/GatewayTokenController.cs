using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WorkBench.Api.Services.SqlGateway;

namespace WorkBench.Api.Controllers;

[Authorize(Policy = "GatewayTokenPage")]
[Route("gateway/token")]
public sealed class GatewayTokenController(IWorkbenchTokenIssuer issuer, ILogger<GatewayTokenController> logger) : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        Response.Headers.CacheControl = "no-store";
        return View("~/Views/GatewayToken/Index.cshtml");
    }

    [HttpPost("generate")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Generate(CancellationToken cancellationToken)
    {
        Response.Headers.CacheControl = "no-store";
        try
        {
            var token = await issuer.IssueAsync(User, cancellationToken);
            if (string.IsNullOrWhiteSpace(token.Token) || token.ExpiresAtUtc <= DateTimeOffset.UtcNow)
                throw new InvalidOperationException("The issuer returned an invalid token.");
            return Ok(new { token = token.Token, expiresAtUtc = token.ExpiresAtUtc });
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception exception)
        {
            logger.LogError(exception, "Gateway token generation failed. CorrelationId={CorrelationId}", HttpContext.TraceIdentifier);
            return StatusCode(503, new { message = "Token generation is unavailable.", correlationId = HttpContext.TraceIdentifier });
        }
    }
}
