using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using WorkBench.Api.Options;
using WorkBench.Api.Services.SqlGateway;
using Xunit;

namespace WorkBench.Api.Tests.SqlGateway;

public sealed class DbSessionServiceTests
{
    [Fact]
    public void SessionIsBoundToClientAndCountsStatements()
    {
        using var cache = new MemoryCache(new MemoryCacheOptions());
        var service = new DbSessionService(cache, Options.Create(new SqlGatewayOptions()), TimeProvider.System);
        var opened = service.Open("client-a");

        Assert.False(service.TryGetAndTouch(opened.SessionId, "client-b", out _));
        Assert.True(service.TryGetAndTouch(opened.SessionId, "client-a", out var touched));
        Assert.Equal(1, touched!.StatementCount);
        Assert.True(service.Close(opened.SessionId, "client-a"));
        Assert.False(service.TryGetAndTouch(opened.SessionId, "client-a", out _));
    }
}
