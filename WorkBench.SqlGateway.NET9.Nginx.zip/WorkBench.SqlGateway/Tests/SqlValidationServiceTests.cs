using Microsoft.Extensions.Options;
using WorkBench.Api.Options;
using WorkBench.Api.Services.SqlGateway;
using Xunit;

namespace WorkBench.Api.Tests.SqlGateway;

public sealed class SqlValidationServiceTests
{
    private readonly SqlValidationService _sut = new(Options.Create(new SqlGatewayOptions()));

    [Theory]
    [InlineData("select * from employees", "SELECT")]
    [InlineData("WITH x AS (SELECT 1 n FROM dual) SELECT n FROM x", "SELECT")]
    [InlineData("insert into audit_log(id) values (:id)", "INSERT")]
    [InlineData("update employees set name=:name where id=:id", "UPDATE")]
    [InlineData("delete from employees where id=:id", "DELETE")]
    public void AcceptsSupportedStatements(string sql, string expectedType)
    {
        var result = _sut.Validate(sql);
        Assert.True(result.IsValid, result.Error);
        Assert.Equal(expectedType, result.StatementType);
    }

    [Theory]
    [InlineData("drop table employees")]
    [InlineData("select * from employees; delete from employees")]
    [InlineData("select * from employees -- bypass")]
    [InlineData("select * from employees /* bypass */")]
    [InlineData("begin null; end;")]
    [InlineData("select dbms_metadata.get_ddl('TABLE','X') from dual")]
    [InlineData("select * from employees for update")]
    [InlineData("with function f return number is begin return 1; end; select f from dual")]
    public void RejectsUnsafeStatements(string sql) => Assert.False(_sut.Validate(sql).IsValid);

    [Fact]
    public void DoesNotTreatCommentMarkersInsideStringAsComments()
        => Assert.True(_sut.Validate("select '-- not a comment' value from dual").IsValid);
}
