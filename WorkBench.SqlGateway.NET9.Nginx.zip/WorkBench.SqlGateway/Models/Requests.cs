using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace WorkBench.Api.Models.SqlGateway;

public sealed record OpenSessionRequest;

public sealed record SqlExecuteRequest
{
    [Required]
    public Guid SessionId { get; init; }

    [Required, MinLength(1)]
    public string Sql { get; init; } = string.Empty;

    public Dictionary<string, JsonElement> Parameters { get; init; } = new(StringComparer.OrdinalIgnoreCase);

    [Range(1, 100_000)]
    public int? MaxRows { get; init; }

    [Range(1, 600)]
    public int? TimeoutSeconds { get; init; }
}

public sealed record CloseSessionRequest
{
    [Required]
    public Guid SessionId { get; init; }
}
