using System.Text.Json;

namespace WorkBench.Api.Models.SqlGateway;

public sealed record OpenSessionResponse(
    bool Success,
    Guid SessionId,
    DateTimeOffset ExpiresAtUtc,
    string Message,
    string CorrelationId);

public sealed record SqlExecuteResponse
{
    public bool Success { get; init; }
    public string? StatementType { get; init; }
    public int RowCount { get; init; }
    public int AffectedRows { get; init; }
    public IReadOnlyList<IReadOnlyDictionary<string, object?>> Rows { get; init; } = [];
    public string Message { get; init; } = string.Empty;
    public string CorrelationId { get; init; } = string.Empty;
}

public sealed record CloseSessionResponse(bool Success, string Message, string CorrelationId);

public sealed record ApiErrorResponse(bool Success, string Message, string CorrelationId)
{
    public static ApiErrorResponse Create(string message, string correlationId) => new(false, message, correlationId);
}

public sealed record SqlParameterValue(string Name, JsonElement Value);
