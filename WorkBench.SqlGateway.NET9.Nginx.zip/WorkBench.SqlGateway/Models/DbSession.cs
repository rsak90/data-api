namespace WorkBench.Api.Models.SqlGateway;

public sealed record DbSession(
    Guid SessionId,
    string ClientId,
    DateTimeOffset CreatedAtUtc,
    DateTimeOffset LastAccessedAtUtc,
    DateTimeOffset ExpiresAtUtc,
    long StatementCount);
