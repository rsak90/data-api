using Microsoft.Extensions.DependencyInjection.Extensions;
using WorkBench.Api.Options;
using WorkBench.Api.Repositories.SqlGateway;
using WorkBench.Api.Services.SqlGateway;

namespace WorkBench.Api.Integration;

public static class SqlGatewayServiceCollectionExtensions
{
    public static IServiceCollection AddSqlGateway(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<SqlGatewayOptions>()
            .Bind(configuration.GetSection(SqlGatewayOptions.SectionName))
            .ValidateDataAnnotations()
            .Validate(o => o.SlidingTimeoutMinutes <= o.AbsoluteTimeoutMinutes,
                "Sliding timeout must not exceed absolute timeout.")
            .Validate(o => o.DefaultMaxRows <= o.MaximumMaxRows,
                "DefaultMaxRows must not exceed MaximumMaxRows.")
            .Validate(o => o.DefaultCommandTimeoutSeconds <= o.MaximumCommandTimeoutSeconds,
                "DefaultCommandTimeoutSeconds must not exceed MaximumCommandTimeoutSeconds.")
            .ValidateOnStart();

        services.AddMemoryCache();
        services.TryAddSingleton(TimeProvider.System);
        services.AddSingleton<IDbSessionService, DbSessionService>();
        services.AddSingleton<ISqlValidationService, SqlValidationService>();
        services.AddScoped<ISqlGatewayRepository, SqlGatewayRepository>();
        services.AddScoped<ISqlGatewayService, SqlGatewayService>();
        services.TryAddScoped<IWorkbenchTokenIssuer, UnconfiguredWorkbenchTokenIssuer>();
        return services;
    }
}
