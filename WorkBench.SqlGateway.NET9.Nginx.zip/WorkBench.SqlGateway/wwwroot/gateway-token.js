const form = document.getElementById('token-form');
const status = document.getElementById('status');
const result = document.getElementById('result');
const token = document.getElementById('token');
form.addEventListener('submit', async event => {
  event.preventDefault();
  form.querySelector('button').disabled = true;
  result.hidden = true;
  token.value = '';
  status.textContent = 'Generating token…';
  try {
    const response = await fetch(form.action, {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      body: new FormData(form), headers: { Accept: 'application/json' }
    });
    if (response.redirected) throw new Error('Your sign-in expired. Reload this page and sign in again.');
    const body = await response.json();
    if (!response.ok) throw new Error(body.message || 'Token generation failed.');
    token.value = body.token;
    document.getElementById('expiry').textContent = `Expires: ${new Date(body.expiresAtUtc).toLocaleString()}`;
    result.hidden = false;
    status.textContent = 'Token generated.';
  } catch (error) { status.textContent = error.message; }
  finally { form.querySelector('button').disabled = false; }
});
document.getElementById('download').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob([token.value + '\n'], { type: 'text/plain' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'token.txt';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
