using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Identity;

Console.Error.Write("Username: ");
var username = Console.ReadLine()?.Trim();
if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("Username is required.");
Console.Error.Write("Password (hidden, minimum 12 characters): ");
var password = new StringBuilder();
while (true)
{
    var key = Console.ReadKey(intercept: true);
    if (key.Key == ConsoleKey.Enter) break;
    if (key.Key == ConsoleKey.Backspace) { if (password.Length > 0) password.Length--; }
    else if (!char.IsControl(key.KeyChar)) password.Append(key.KeyChar);
}
Console.Error.WriteLine();
if (password.Length < 12) throw new ArgumentException("Use a password of at least 12 characters.");
var user = new Account { Id = Guid.NewGuid().ToString(), Username = username };
user.PasswordHash = new PasswordHasher<Account>().HashPassword(user, password.ToString());
Console.WriteLine(JsonSerializer.Serialize(new
{
    GatewayAuth = new
    {
        Issuer = "WorkBench", Audience = "WorkBench.SqlGateway", TokenLifetimeMinutes = 60,
        SigningKeyBase64 = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)), Users = new[] { user }
    }
}, new JsonSerializerOptions { WriteIndented = true }));

public sealed class Account
{
    public string Id { get; set; } = "";
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public bool Enabled { get; set; } = true;
}
