using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using WorkBench.Api.Options;

namespace WorkBench.Api.Services.SqlGateway;

public sealed partial class SqlValidationService(IOptions<SqlGatewayOptions> options) : ISqlValidationService
{
    private static readonly HashSet<string> AllowedStarts = new(StringComparer.OrdinalIgnoreCase)
        { "SELECT", "WITH", "INSERT", "UPDATE", "DELETE" };

    private static readonly HashSet<string> DeniedWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "CREATE", "ALTER", "DROP", "TRUNCATE", "MERGE", "GRANT", "REVOKE", "COMMIT", "ROLLBACK",
        "DECLARE", "BEGIN", "CALL", "EXEC", "EXECUTE", "IMMEDIATE", "LOCK", "ANALYZE", "AUDIT",
        "NOAUDIT", "COMMENT", "RENAME", "FLASHBACK", "PURGE", "EXPLAIN", "FUNCTION", "PROCEDURE"
    };

    private readonly SqlGatewayOptions _options = options.Value;

    public SqlValidationResult Validate(string sql)
    {
        if (string.IsNullOrWhiteSpace(sql)) return SqlValidationResult.Invalid("SQL is required.");
        if (sql.Length > _options.MaxSqlLength)
            return SqlValidationResult.Invalid($"SQL exceeds the configured maximum length of {_options.MaxSqlLength} characters.");

        var scan = Scan(sql);
        if (scan.Error is not null) return SqlValidationResult.Invalid(scan.Error);

        var words = WordRegex().Matches(scan.Normalized).Select(m => m.Value).ToArray();
        if (words.Length == 0 || !AllowedStarts.Contains(words[0]))
            return SqlValidationResult.Invalid("Only SELECT, WITH, INSERT, UPDATE, and DELETE statements are allowed.");

        var denied = words.FirstOrDefault(DeniedWords.Contains);
        if (denied is not null) return SqlValidationResult.Invalid($"Unsafe SQL construct '{denied}' is not allowed.");

        if (DangerousPackageRegex().IsMatch(scan.Normalized))
            return SqlValidationResult.Invalid("Access to privileged Oracle packages or system objects is not allowed.");

        if (words[0].Equals("WITH", StringComparison.OrdinalIgnoreCase) &&
            words.Skip(1).Any(w => w.Equals("INSERT", StringComparison.OrdinalIgnoreCase) ||
                                   w.Equals("UPDATE", StringComparison.OrdinalIgnoreCase) ||
                                   w.Equals("DELETE", StringComparison.OrdinalIgnoreCase)))
            return SqlValidationResult.Invalid("A WITH statement must resolve to a SELECT query.");

        if (ForUpdateRegex().IsMatch(scan.Normalized))
            return SqlValidationResult.Invalid("SELECT FOR UPDATE is not allowed.");

        var type = words[0].Equals("WITH", StringComparison.OrdinalIgnoreCase)
            ? ResolveWithStatementType(words)
            : words[0].ToUpperInvariant();
        return SqlValidationResult.Valid(type);
    }

    private static string ResolveWithStatementType(string[] words)
    {
        // Oracle WITH clauses used here must ultimately query data. DML after a CTE is rejected conservatively.
        var selectIndex = Array.FindIndex(words, 1, w => w.Equals("SELECT", StringComparison.OrdinalIgnoreCase));
        if (selectIndex < 0) return "WITH";
        return "SELECT";
    }

    private static (string Normalized, string? Error) Scan(string sql)
    {
        var normalized = new StringBuilder(sql.Length);
        var inString = false;
        var inQuotedIdentifier = false;
        for (var i = 0; i < sql.Length; i++)
        {
            var c = sql[i];
            if (inString)
            {
                normalized.Append(' ');
                if (c == '\'' && i + 1 < sql.Length && sql[i + 1] == '\'') { normalized.Append(' '); i++; }
                else if (c == '\'') inString = false;
                continue;
            }
            if (inQuotedIdentifier)
            {
                normalized.Append(' ');
                if (c == '"' && i + 1 < sql.Length && sql[i + 1] == '"') { normalized.Append(' '); i++; }
                else if (c == '"') inQuotedIdentifier = false;
                continue;
            }
            if (c == '\'') { inString = true; normalized.Append(' '); continue; }
            if (c == '"') { inQuotedIdentifier = true; normalized.Append(' '); continue; }
            if (c == ';') return (string.Empty, "Statement terminators and multiple statements are not allowed.");
            if (c == '-' && i + 1 < sql.Length && sql[i + 1] == '-') return (string.Empty, "SQL comments are not allowed.");
            if (c == '/' && i + 1 < sql.Length && sql[i + 1] == '*') return (string.Empty, "SQL comments are not allowed.");
            normalized.Append(c);
        }
        if (inString || inQuotedIdentifier) return (string.Empty, "SQL contains an unterminated literal or quoted identifier.");
        return (normalized.ToString(), null);
    }

    [GeneratedRegex(@"[A-Za-z][A-Za-z0-9_$#]*", RegexOptions.CultureInvariant)]
    private static partial Regex WordRegex();

    [GeneratedRegex(@"\b(?:DBMS_[A-Z0-9_$#]*|UTL_[A-Z0-9_$#]*|SYS\s*\.|SYSTEM\s*\.|V\$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex DangerousPackageRegex();

    [GeneratedRegex(@"\bFOR\s+UPDATE\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex ForUpdateRegex();
}
