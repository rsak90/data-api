using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using WorkBench.Api.Models.SqlGateway;
using WorkBench.Api.Options;

namespace WorkBench.Api.Services.SqlGateway;

public sealed class DbSessionService(IMemoryCache cache, IOptions<SqlGatewayOptions> options, TimeProvider timeProvider)
    : IDbSessionService
{
    private readonly object _gate = new();
    private readonly SqlGatewayOptions _options = options.Value;

    public DbSession Open(string clientId)
    {
        var now = timeProvider.GetUtcNow();
        var session = new DbSession(Guid.NewGuid(), clientId, now, now,
            now.AddMinutes(_options.AbsoluteTimeoutMinutes), 0);
        Set(session);
        return session;
    }

    public bool TryGetAndTouch(Guid sessionId, string clientId, out DbSession? session)
    {
        lock (_gate)
        {
            if (!cache.TryGetValue(Key(sessionId), out DbSession? current) || current is null ||
                !string.Equals(current.ClientId, clientId, StringComparison.Ordinal))
            {
                session = null;
                return false;
            }

            var now = timeProvider.GetUtcNow();
            if (now >= current.ExpiresAtUtc)
            {
                cache.Remove(Key(sessionId));
                session = null;
                return false;
            }

            session = current with { LastAccessedAtUtc = now, StatementCount = checked(current.StatementCount + 1) };
            Set(session);
            return true;
        }
    }

    public bool Close(Guid sessionId, string clientId)
    {
        lock (_gate)
        {
            if (!cache.TryGetValue(Key(sessionId), out DbSession? session) || session is null ||
                !string.Equals(session.ClientId, clientId, StringComparison.Ordinal)) return false;
            cache.Remove(Key(sessionId));
            return true;
        }
    }

    private void Set(DbSession session) => cache.Set(Key(session.SessionId), session, new MemoryCacheEntryOptions
    {
        AbsoluteExpiration = session.ExpiresAtUtc,
        SlidingExpiration = TimeSpan.FromMinutes(_options.SlidingTimeoutMinutes),
    });

    private static string Key(Guid id) => $"sql-gateway-session:{id:N}";
}
