using WorkBench.Api.Models.SqlGateway;

namespace WorkBench.Api.Services.SqlGateway;

public interface IDbSessionService
{
    DbSession Open(string clientId);
    bool TryGetAndTouch(Guid sessionId, string clientId, out DbSession? session);
    bool Close(Guid sessionId, string clientId);
}
