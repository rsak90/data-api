using Microsoft.Extensions.Options;
using WorkBench.Api.Models.SqlGateway;
using WorkBench.Api.Options;
using WorkBench.Api.Repositories.SqlGateway;

namespace WorkBench.Api.Services.SqlGateway;

public sealed class SqlGatewayService(
    IDbSessionService sessions,
    ISqlValidationService validator,
    ISqlGatewayRepository repository,
    IOptions<SqlGatewayOptions> options) : ISqlGatewayService
{
    private readonly SqlGatewayOptions _options = options.Value;

    public Task<SqlExecuteResponse> ExecuteAsync(
        SqlExecuteRequest request, string clientId, string correlationId, CancellationToken cancellationToken)
    {
        if (!sessions.TryGetAndTouch(request.SessionId, clientId, out _))
            throw new SqlGatewaySessionException("The database session is invalid, expired, or belongs to another client.");

        var validation = validator.Validate(request.Sql);
        if (!validation.IsValid) throw new SqlGatewayValidationException(validation.Error!);

        var maxRows = request.MaxRows ?? _options.DefaultMaxRows;
        if (maxRows > _options.MaximumMaxRows)
            throw new SqlGatewayValidationException($"MaxRows cannot exceed {_options.MaximumMaxRows}.");
        var timeout = request.TimeoutSeconds ?? _options.DefaultCommandTimeoutSeconds;
        if (timeout > _options.MaximumCommandTimeoutSeconds)
            throw new SqlGatewayValidationException($"TimeoutSeconds cannot exceed {_options.MaximumCommandTimeoutSeconds}.");

        var command = new SqlGatewayCommand(request.Sql, validation.StatementType!, request.Parameters, maxRows, timeout);
        return repository.ExecuteAsync(command, correlationId, cancellationToken);
    }
}

public sealed class SqlGatewayValidationException(string message) : Exception(message);
public sealed class SqlGatewaySessionException(string message) : Exception(message);
