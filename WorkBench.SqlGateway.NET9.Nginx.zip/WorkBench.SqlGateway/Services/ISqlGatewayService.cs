using WorkBench.Api.Models.SqlGateway;

namespace WorkBench.Api.Services.SqlGateway;

public interface ISqlGatewayService
{
    Task<SqlExecuteResponse> ExecuteAsync(SqlExecuteRequest request, string clientId, string correlationId, CancellationToken cancellationToken);
}
