namespace WorkBench.Api.Services.SqlGateway;

public sealed record SqlValidationResult(bool IsValid, string? StatementType, string? Error)
{
    public static SqlValidationResult Valid(string statementType) => new(true, statementType, null);
    public static SqlValidationResult Invalid(string error) => new(false, null, error);
}

public interface ISqlValidationService
{
    SqlValidationResult Validate(string sql);
}
