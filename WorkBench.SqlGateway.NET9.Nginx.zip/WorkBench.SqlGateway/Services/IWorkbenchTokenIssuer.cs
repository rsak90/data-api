using System.Security.Claims;

namespace WorkBench.Api.Services.SqlGateway;

/// <summary>Issues a gateway token for an authenticated user.</summary>
public interface IWorkbenchTokenIssuer
{
    Task<GeneratedGatewayToken> IssueAsync(ClaimsPrincipal user, CancellationToken cancellationToken);
}

public sealed record GeneratedGatewayToken(string Token, DateTimeOffset ExpiresAtUtc);

/// <summary>Fail closed until the application's existing JWT issuer is connected.</summary>
public sealed class UnconfiguredWorkbenchTokenIssuer : IWorkbenchTokenIssuer
{
    public Task<GeneratedGatewayToken> IssueAsync(ClaimsPrincipal user, CancellationToken cancellationToken)
        => throw new InvalidOperationException("Connect IWorkbenchTokenIssuer to the existing WorkBench JWT issuer before enabling token generation.");
}
