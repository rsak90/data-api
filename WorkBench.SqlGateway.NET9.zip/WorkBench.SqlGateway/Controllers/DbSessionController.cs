using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WorkBench.Api.Models.SqlGateway;
using WorkBench.Api.Services.SqlGateway;

namespace WorkBench.Api.Controllers;

[ApiController]
[Authorize] // Reuses the existing JWT authentication/authorization pipeline (and its CipherService integration).
[Route("api/dbsession")]
[Produces("application/json")]
public sealed class DbSessionController(
    IDbSessionService sessions,
    ISqlGatewayService gateway,
    ILogger<DbSessionController> logger) : ControllerBase
{
    [HttpPost("open")]
    [ProducesResponseType<OpenSessionResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized)]
    public ActionResult<OpenSessionResponse> Open([FromBody] OpenSessionRequest _, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var correlationId = CorrelationId();
        var session = sessions.Open(GetClientId());
        logger.LogInformation("SQL gateway session {SessionId} opened for client {ClientId}. CorrelationId={CorrelationId}",
            session.SessionId, session.ClientId, correlationId);
        return Ok(new OpenSessionResponse(true, session.SessionId, session.ExpiresAtUtc,
            "Logical database session opened.", correlationId));
    }

    [HttpPost("execute")]
    [ProducesResponseType<SqlExecuteResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<SqlExecuteResponse>> Execute(
        [FromBody] SqlExecuteRequest request, CancellationToken cancellationToken)
    {
        var correlationId = CorrelationId();
        try
        {
            var response = await gateway.ExecuteAsync(request, GetClientId(), correlationId, cancellationToken);
            logger.LogInformation("SQL {StatementType} completed. Rows={RowCount}, Affected={AffectedRows}, CorrelationId={CorrelationId}",
                response.StatementType, response.RowCount, response.AffectedRows, correlationId);
            return Ok(response);
        }
        catch (SqlGatewaySessionException ex) { return NotFound(ApiErrorResponse.Create(ex.Message, correlationId)); }
        catch (SqlGatewayValidationException ex) { return BadRequest(ApiErrorResponse.Create(ex.Message, correlationId)); }
        catch (ArgumentException ex) { return BadRequest(ApiErrorResponse.Create(ex.Message, correlationId)); }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            logger.LogError(ex, "SQL gateway execution failed. CorrelationId={CorrelationId}", correlationId);
            return StatusCode(StatusCodes.Status500InternalServerError,
                ApiErrorResponse.Create("Database execution failed. Use the correlation ID when contacting support.", correlationId));
        }
    }

    [HttpPost("close")]
    [ProducesResponseType<CloseSessionResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiErrorResponse>(StatusCodes.Status404NotFound)]
    public ActionResult<CloseSessionResponse> Close([FromBody] CloseSessionRequest request, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var correlationId = CorrelationId();
        if (!sessions.Close(request.SessionId, GetClientId()))
            return NotFound(ApiErrorResponse.Create("The database session was not found.", correlationId));
        logger.LogInformation("SQL gateway session {SessionId} closed. CorrelationId={CorrelationId}", request.SessionId, correlationId);
        return Ok(new CloseSessionResponse(true, "Logical database session closed.", correlationId));
    }

    private string GetClientId() =>
        User.FindFirstValue("client_id") ?? User.FindFirstValue(ClaimTypes.NameIdentifier) ??
        User.FindFirstValue("sub") ?? throw new UnauthorizedAccessException("JWT does not contain a supported client identity claim.");

    private string CorrelationId()
    {
        var id = HttpContext.TraceIdentifier;
        Response.Headers["X-Correlation-ID"] = id;
        return id;
    }
}
