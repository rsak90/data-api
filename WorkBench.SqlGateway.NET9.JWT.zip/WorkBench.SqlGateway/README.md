# WorkBench SQL Gateway (.NET 9 integration package)

**Authentication update:** use `AUTHENTICATION.md` and `Integration/CompleteAuthentication.cs.snippet` for the implemented user login and JWT issuance/validation. They supersede the earlier authentication adapter instructions below. No existing JWT issuer or browser scheme is required for the gateway.

## Per-user token page

Copy `Views/` and `wwwroot/` into the existing API project along with `GatewayTokenController` and `IWorkbenchTokenIssuer`. Merge `Integration/TokenGeneration.cs.snippet` into the existing Program.cs. The separate `/gateway/token` page requires the existing browser cookie/SSO login, checks antiforgery on token generation, and returns a token only for the signed-in user. The user can download `token.txt` and transfer it to `/jcr/Ajith_Kumar/Token/token.txt` in SAS. The existing SAS macros already send that token as `Authorization: Bearer <token>` on OPEN, EXECUTE and CLOSE.

The existing WorkBench JWT issuer and browser login scheme were not provided. Implement `IWorkbenchTokenIssuer` by calling that existing service and replace the browser scheme placeholder in the snippet. The supplied default issuer fails closed with HTTP 503: it never fabricates credentials or tokens. Until these two integrations are supplied, token generation is incomplete. Configure the existing API bearer handler to verify the resulting JWT signature, issuer, audience and expiry. For browser users without SQL permissions, apply the existing SQL-access permission/role to both the page and API policies.

This package adds a logical-session SQL Gateway to the **existing** WorkBench ASP.NET Core API. It is deliberately not a standalone API: `SqlGatewayRepository` takes the existing `WorkbenchContext` and obtains its pooled Oracle connection with `context.Database.GetDbConnection()`.

## Copy into the existing solution

Copy these folders into the WorkBench API project, preserving their folder names:

- `Controllers/`
- `Models/`
- `Options/`
- `Repositories/`
- `Services/`
- `Integration/SqlGatewayServiceCollectionExtensions.cs`
- `SAS/` (normally deploy this beside the SAS programs rather than into the API publish output)

Then:

1. Add `builder.Services.AddSqlGateway(builder.Configuration);` from `Integration/Program.cs.snippet` to the existing `Program.cs`.
2. Merge the `SqlGateway` object from `Integration/appsettings.SqlGateway.json` into the existing `appsettings.json` and environment overrides.
3. Confirm the existing API references compatible .NET 9 EF Core and Oracle provider packages. See `Integration/WorkBench.Api.csproj.snippet`; do not duplicate or downgrade packages already used by `WorkbenchContext`.
4. Build, run the existing tests plus the supplied tests, and test against a least-privilege non-production Oracle schema before deployment.

## Small integration placeholders to replace

The screenshots did not expose the exact WorkBench namespaces, auth policy, or claim conventions. Search for `INTEGRATION:` and make these small substitutions:

- Change `using WorkBench.Api.Data` if `WorkbenchContext` has another namespace or capitalization.
- Change the root namespace `WorkBench.Api` throughout if the existing project uses a different one.
- `DbSessionController` uses plain `[Authorize]`. If WorkBench requires a named JWT policy, use `[Authorize(Policy = "<existing-policy>")]`.
- `GetClientId()` checks `client_id`, `ClaimTypes.NameIdentifier`, then `sub`. Align this order with the existing JWT claims. Never accept `ClientId` from the request body.
- The existing `CipherService` is not duplicated or called directly. The controller reuses the existing JWT authentication pipeline, where token validation/decryption belongs. If the current authentication handler exposes an encrypted client claim that requires `CipherService`, inject the existing service into the identity/claims adapter and replace `GetClientId()` accordingly.
- Keep the existing `AddDbContext<WorkbenchContext>`, Oracle connection string, pooling settings, logging providers, exception middleware, health checks, and deployment pipeline. This package intentionally does not replace them.

## Endpoint contracts

All endpoints require the existing JWT bearer authentication.

`POST /api/dbsession/open`

```json
{}
```

`POST /api/dbsession/execute`

```json
{
  "sessionId": "7cad0ad0-07b8-489d-bbed-5f4c783faf4e",
  "sql": "select employee_id from employees where department_id = :departmentId",
  "parameters": { "departmentId": 10 },
  "maxRows": 1000,
  "timeoutSeconds": 30
}
```

`POST /api/dbsession/close`

```json
{ "sessionId": "7cad0ad0-07b8-489d-bbed-5f4c783faf4e" }
```

Success responses expose `success`, `statementType`, `rowCount`, `affectedRows`, `rows`, `message`, and `correlationId` where applicable. Server errors do not disclose Oracle messages; the full exception is sent only to the existing structured logs with the correlation ID.

## Session and connection behavior

- Sessions are logical records in `IMemoryCache`; they never own an Oracle connection.
- Absolute expiry is 60 minutes and never moves. The 20-minute sliding expiry is refreshed on successful lookup.
- A session is bound to the authenticated client identity. Another client cannot execute or close it.
- Each statement uses the scoped context connection, opens it only when needed, and closes it in `finally`, returning it to the existing Oracle pool.
- In a multi-instance deployment, `IMemoryCache` requires sticky routing for a session. This is inherent in the requirement to use in-memory sessions. Restarts invalidate sessions. If sticky routing is unavailable, changing to a distributed session store is an architectural change.

## SQL controls

The validator allows only `SELECT`, query-form `WITH`, `INSERT`, `UPDATE`, and `DELETE`. It rejects semicolons/multiple statements, comments, excessive length, DDL, transaction control, PL/SQL, administrative commands, `SELECT FOR UPDATE`, and common privileged Oracle packages/system objects. Bind values are supplied through `parameters`, and Oracle commands enable `BindByName`.

Validation is defense in depth, not a SQL parser or authorization boundary. The Oracle account must still have least privilege: only the intended schemas/tables, no DDL or administrative grants, and no dangerous execute privileges. Review whether arbitrary allowed DML is appropriate for each caller; add application-level table/operation allowlists if clients are not fully trusted.

Writes execute inside a fresh `ReadCommitted` transaction, commit only on success, and attempt rollback on every failure. A `SELECT` reads at most the configured row count; the message reports when the limit is reached.

## SAS deployment

Deploy `dbcon.sas`, `dbsql.sas`, and `dbdisconnect.sas` to a SAS-readable directory and update the `%include` paths in `example.sas`. `%dbcon` reads the JWT from `/jcr/Ajith_Kumar/Token/token.txt` by default. The token is held only in a local macro variable for the request. Restrict filesystem access to that token.

The SAS JSON engine infers output column types from returned data. Mixed Oracle types in one column or very long values may need a site-specific JSON map. The macros populate:

- `gdbsessionid`, `gdbconnected`
- `db_statement_type`, `db_row_count`, `db_affected_rows`
- `db_message`, `db_correlation_id`

## Operational checklist

- Configure reverse-proxy and ASP.NET request body limits consistently with `MaxSqlLength`.
- Keep HTTPS mandatory and never log JWTs, parameter values, or raw SQL unless the existing data-classification policy explicitly permits it.
- Apply rate limiting using the existing WorkBench policy, keyed by authenticated client.
- Verify Oracle command cancellation and timeout behavior with the provider version in production.
- Monitor execution count, latency, failures, affected rows, and cache pressure using the existing logging/metrics stack.
- For write access, use a dedicated Oracle service account with narrowly scoped grants and database auditing.

## Tests

`Tests/` contains xUnit coverage for the critical validator and logical-session behavior. Copy these files into the existing WorkBench test project and update namespaces/references as needed. Add integration tests using the existing Oracle test environment for pooling, `BindByName`, commit/rollback, cancellation, JSON type conversion, and authorization.
